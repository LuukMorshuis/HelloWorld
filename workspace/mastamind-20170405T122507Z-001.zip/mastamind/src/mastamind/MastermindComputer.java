package mastamind;

public class MastermindComputer {

}
