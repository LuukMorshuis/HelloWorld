package mastamind;


import java.util.Random;

public class Main {

	public static void main(String[] args) {
	
		Mastermind asd = new Mastermind();

		asd.play();

	}

}

