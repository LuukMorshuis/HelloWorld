package mastamind;

public class Application {


}
