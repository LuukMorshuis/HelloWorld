package mastamind;

public class MastermindHuman {

}
